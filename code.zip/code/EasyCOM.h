/******************************************************************************
 Copyright (c) 2007 MegaWin Inc.
 All rights reserved.
 Module Name: EasyCOM.H
 Abstract: USB Library for MG84FG516
 Author: ShengZhong Shieh ( MAIL: shengzhong@megawin.com.tw , TEL:886-3-5750050#1510 )
 Update date: 2008/03/10
 Reversion History: v1.00
*******************************************************************************/
#ifndef EASYCOM_H
#define EASYCOM_H

#include "main.h"
/******************************* Initial Condition*****************************
 Crystal input should be force at 12Mhz
*******************************************************************************/
#define    XTAL_12Mhz

#define    SET         1
#define    CLR         0

#define    BIT         bit
#define    BYTE        unsigned char
#define    WORD        unsigned int
//#define    DWORD       unsigned long

//#define    XBYTE       BYTE volatile xdata
 



#define		USBInterruptOn		EIE1 |= 0x80
#define		USBInterruptOff		EIE1 &= 0x7f
#define    HIBYTE( V1 )     ((BYTE)((V1) >> 8))
#define    LOBYTE( V1 )     ((BYTE)((V1) & 0xFF))
/*********************************** ID ***************************************
 USB_VID  -> This VID is registered under Megawin Technology Co., Ltd. at USB-IF.
             Any third party needs the written approval from Megawin in order to
             use this VID.
*******************************************************************************/
#define    USB_VID          0xE6A
#define    USB_PID          0x316
#define    USB_DID          0x108

#define    MF_STRING                             // Supported Manufacture String
#define    PD_STRING                             // Supported Product String
//#define    SN_STRING                             // Supported SerialNumber String

#define    UART_RX_CARRIER          0x01
#define    UART_TX_CARRIER          0x02
#define    UART_BREAK               0x04
#define    UART_RING_SIGNAL         0x08
#define    UART_FRAM_ERROR          0x10
#define    UART_PARITY_ERROR        0x20
#define    UART_OVER_RUN            0x40

union WTYPE
{ 
	BYTE 	B[2];
    WORD 	W;
};
  
union DWTYPE
{ 
	BYTE 	B[4];
    WORD 	W[2];
    DWord 	DW;
};

typedef struct
{
  	 BYTE Suspend : 1;
     BYTE Reset : 1;
     BYTE WakeUp : 1;
     BYTE EmuOK : 1;
     BYTE Res4 : 1;
     BYTE Res5 : 1;
     BYTE Res6 : 1;
     BYTE Res7 : 1;
}USBEVENT;

typedef struct
{ 
	 BYTE Flag;                                  // Set by Host setting occur
     union DWTYPE BaudRate;
     BYTE StopBit;
     BYTE ParityChk;
     BYTE DataBit;
}LINECODING;                                 // 

typedef struct
{ 	
	BYTE Flag;                                  // Set by Host setting occur
    BYTE State;                                 // D0 for DTR , D1 for RTS
}LINESTATE;

typedef struct
{ 
	BYTE Flag;                                  // Set by Host setting occur
    union WTYPE Time;                           // 0xFFFF for break forver , 0x0000 for release
}SENDBREAK;

typedef struct
{ 
	LINECODING LC;
    LINESTATE LS;
    SENDBREAK SB;
    BYTE State;
}COM;     

//-----Device Descriptor-----//
//-----MANUFACTURER(UNICODE) in String Descriptor-----//
//-----PRODUCT(UNICODE) in String Descriptor-----//
//-----Serial Number in String Descriptor-----//
extern 	code BYTE DEVICE_DESCRIPTOR[];
extern 	code BYTE LANGUAGEID_DESCRIPTOR[];
extern 	code BYTE MANUFACTURER_DESCRIPTOR[];
extern 	code BYTE PRODUCT_DESCRIPTOR[];
extern 	code BYTE SERIALNUMBER_DESCRIPTOR[]; 

/**************************** Data In Parameter *******************************

 InFlag       -> The flag will be " SET " when MG84FG516 receive data from PC
                 and stored in InBuffer[64] already.
 InLen        -> Size of data that stored in InBuffer[64]
 USBTxBuf[64] = InBuffer[64] -> Data buffer

*******************************************************************************/
extern     BIT InFlag;
extern     BYTE InLen;
extern     Byte xdata InBuffer[64];
extern	   Byte xdata USBTxBuf[256] ;
extern	   Byte xdata USBRxBuf[256] ;

extern	   bit USBReceFlag,Usb_TxFinish;

extern     USBEVENT UsbEvent;
extern     COM idata  Com;
/****************************** Function Call *********************************
 Initial();                             -> Will enable USB function that include
                                           " Device Firmware Upgrade " and " COM
                                           port interface "
 USB_Send_Data_To_PC( Size , *Buffer ); ->
                                           Size   --> The maximum number of bytes 
                                                      will be send to PC.
                                          *Buffer --> A pointer to the buffer that 
                                                      content the data will be send 
                                                      to PC.
 USB_Read_Data_Complete();              -> Will release buffer for next data  
                                           transfer from PC
 USB_Send_UartState_To_PC( Status );    -> Uart state will be send to PC
*******************************************************************************/
/*extern     void Initial( void );
extern     void USB_Send_Data_To_PC( BYTE , BYTE * );
extern     void USB_Read_Data_Complete( void );
extern     void USB_Send_UartState_To_PC( BYTE );  */

void Initial( void );
extern void USB_Send_Data_To_PC(BYTE,BYTE * );
void USB_Read_Data_Complete(void);
void USB_Send_UartState_To_PC(BYTE);

/******************************************************************************/
extern void UsbInit();
extern BYTE UsbReceiverComplete();
extern void UsbTransmit();
extern void UsbUartState(BYTE _state);
extern BYTE UsbEventState();
extern void Usb_Tx(BYTE idata _length);
#endif