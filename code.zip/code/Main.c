//******************************************************************************//
//					Autolutiontech												//
//																				//
//		Main.c																	//
//																				//
//			Version 1.0															//
//																				//
//			Author: ken															//
//																				//
//			Date: 2015/03/9														//
//																				//
//******************************************************************************//

#include "main.h"


Byte StateMachine;
Byte MainTaskState;
Byte ExeScrewSubTaskState;

Byte CurrentSFR_Page;
Byte ConnectState;
//Byte idata DO_L, DO_H;
Byte idata DI_L, DI_H;

bit ExRamSelect;
Byte code EncoderCtrlRegSet[4] = {0x00,0x01,0x02,0x03}; 
Byte code EncoderABSCtrlReg[4][4] =
{
	{0x00,0x01,0x02,0x03},	//1024 ABS Gray Code Encoder 
	{0x04,0x05,0x06,0x07},	//1000 ABS Gray Code Encode 
	{0x08,0x09,0x0A,0x0B},	//720 ABS Gray Code Encoder 
	{0x0C,0x0D,0x0E,0x0F}	//8192 ABS Gray Code Encoder 
};
//External SRAM Memory Declare. Set EXTRAM = 1 before use
void main(void)
{
	Byte temp1, temp2, temp3, temp4;
		
	temp1 = 0;
	temp2 = 0;
	temp3 = 0;
	temp4 = 0;
	
	P46 = 0;		//Set MCU_ALE to default 0
	
	ExRamSelect = InternalXRAM;		
	SFR_Page0;
	for(temp1 = 0; temp1 < 16; temp1 ++)
	{
		DebugLED(temp1);
		Delay(10000);
	}
	DebugLED(0);	

	MCU_IO_Init();
	SPI_Init();
	MG82FG5A64_Timer3_Init();

	
//	DisInternalXRAM;		//�i�s���~��SRAM

//	DO_L = 0xFF;
//	DO_H = 0xFF;
	Write_DO(0xFF, 0xFF);

	CPLD2_CtrlReg(0x01);		//ISA_RST_s = 1
	Delay(1000);
	CPLD2_CtrlReg(0x00);		//ISA_RST_s = 0

	Delay(10000);  

/*
// Test Read and Write ISA Bus 
// Tested ok. 20140814 re-tested

	temp1 = Read_ISA_Bus(0x560);
	
	temp2 = Read_ISA_Bus(0x562);
	
	
	Write_ISA_Bus(0x562, 0x3A);
	
	temp2 = Read_ISA_Bus(0x562);
*/


	StateMachine = 0;	
	MainTaskState = MainTaskState_IDLE;
	ExeScrewSubTaskState = ExeScrewSubTaskState_WarmUp;

	UploadState1 = 0xfe;		//Sequential Command UploadState
	UploadState2 = 0xfe;		
	UploadState3 = 0xfe;		
//	CurrentSFR_Page = 0;
//	SFR_Page0;

/*
	UART0_Command = Command_IDLE;
	UART1_Command = Command_IDLE;
	Timer_Command = Command_IDLE;
	DI_Command = Command_IDLE;
	DI_Command_Old = Command_IDLE;
	SelectedGroupNo = 0;
*/

	
//	MG84FG516_SerialInit();		//Serial Port Interrupt enabled here
	SoftTimer_Init();
	InternalXRAM;
	
/*���� Software Timer
   ����ok
	temp2 = GetAvailableTimer();
	SetTimerTarget(temp2, 2000);
	TimerStart(temp2);
	
	temp3 = GetAvailableTimer();
	SetTimerTarget(temp3, 4000);
	TimerStart(temp3);
	
	temp4 = GetAvailableTimer();
	SetTimerTarget(temp4, 10000);
	TimerStart(temp4);
*/	
	

/*
//����InternalXRAM Ū�g. ok. 20140206

	EnInternalXRAM;	
	
	for(temp1 = 0; temp1 < 100; temp1 ++)
	{
		XBYTE[temp1] = 0xFF;
	}
	for(temp1 = 0; temp1 < 100; temp1 ++)
	{
		XBYTE[temp1] = temp1;
	}
	
	//Ū�X
	
	for(temp1 = 0; temp1 < 100; temp1 ++)
	{
		temp2 = XBYTE[temp1];
	}
	
*/
	
	EA = 1;
	
//RS232 Command Test

//	Delay(100000);		//Delay time for S1BRT start to stable
	


//	SFR_Page1;
//	S1BUF = 0xFA;
/*
Test for 19200 ok  20140205
	UART1_TxData[0] = 0xFA;
	UART1_TxData[1] = 0xA0;
	UART1_TxData[2] = 0x00;
	UART1_TxData[3] = 0x03;
	UART1_TxData[4] = 0x30;
	UART1_TxData[5] = 0x02;
	UART1_TxData[6] = 0x21;
	UART1_TxData[7] = 0xFB;

	UART1_TxNumber = 8;

	UART1_Tx();	
*/	
//	SFR_Page0;
//	S0BUF = 0x51;
		
		
//����SPI ����		ok. 2014/11/25
//	SPDAT = 0x55;
//	SPDAT = 0xAA;
		
//	MX25L_RDID();	

/*	
	MX25L_WREN(0);	//Test ok 2014/11/25
	MX25L_RDSR(0);	//Test ok 2014/11/25
	MX25L_ContCheckWEL(0);	
	
	MX25L_ReadStart(0, 0, 0, 0);
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ReadWriteStop();
	
	MX25L_ReadStart(0, 0, 0, 1);
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ReadWriteStop();

//	MX25L_CE(0);
	
	MX25L_ReadStart(0,0,0,0);
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ReadWriteStop();
*/
	
/*
	MX25L_PageProgramStart(0, 0, 0, 0);
	MX25L_ContWrite(0x01);
	MX25L_ContWrite(0x02);
	MX25L_ContWrite(0x03);
	MX25L_ContWrite(0x04);
	MX25L_ContWrite(0x05);
	MX25L_ReadWriteStop();
	MX25L_WRDI(0);
	
	MX25L_ReadStart(0, 0, 0, 0);
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ContRead();
	MX25L_ReadWriteStop();
*/	
	
//	MX25L_WRDI(0);	//Test ok 2014/11/25
//	MX25L_RDSR(0);	//Test ok 2014/11/25
	
	SoftPLC_Init();
	SetFunctionToSram();//Ū�XFLASH default Profile �g�� SRAM
	while(1)
	{	
		ConnectState = UsbEventState();		//Check USB State	
		
		switch(StateMachine)
		{
		case 0:			
			Task_Process_SystemCommand();
			break;
			
		case 1:
			Task_Process_SequentialCommand();		
			break;
			
		case 2:
			Task_Process_OtherEvents();
			break;
			
		case 3:
			Task_Process_DeferredCommand();
			break;

		case 4:			//for ���ե�			
/*			if((UART0_RxStart == 1) && (CheckTimerEvent(UART0_RcvTimer) == 0))
			{
				DebugLED(2);
			}
			else
			if((UART0_RxStart == 1) && (CheckTimerEvent(UART0_RcvTimer)))
			{
				DebugLED(2);
				UART0_RxStart = 0;
				ReleaseTimer(UART0_RcvTimer);
			}

			if(CheckTimerEvent(temp2) > 0)
			{
				DebugLED(1);
				ReleaseTimer(temp2);
			}
			
			if(CheckTimerEvent(temp3) > 0)
			{
				DebugLED(2);
				ReleaseTimer(temp3);
			}
		
			if(CheckTimerEvent(temp4) > 0)
			{
				DebugLED(0);
				ReleaseTimer(temp4);
			}*/		
			break;			

		default:

			break;
			
		} 

		StateMachineIncrement();
	}
}

void DebugLED(Byte Data)
{
	SFR_Page0;
	
	if(Data & 0x01)
	{
		P53 = 0;
	}
	else
	{
		P53 = 1;
	}

	if(Data & 0x02)
	{
		P54 = 0;
	}
	else
	{
		P54 = 1;
	}

	if(Data & 0x04)
	{
		P55 = 0;
	}
	else
	{
		P55 = 1;
	}

	if(Data & 0x08)
	{
		P56 = 0;
	}
	else
	{
		P56 = 1;
	}
	SFR_Page1;
}

void Delay(DWord DelayTime)
{
	while(DelayTime--)
	{
	}
}

void StateMachineIncrement(void)
{
	StateMachine ++;
	if(StateMachine > MaxStateMachine)
	{
		StateMachine = 0;
	}
}

void MCU_IO_Init()
{
	P0M0 = 0x00;		//P0 as open drain mode
	P0 = 0xFF;
	
	P1M0 = 0xFF;		//P1 as push-pull mode
//	P1M0 = 0xF3;		//P1.3  P1.2  as open drain mode, others as push-pull mode. �o�ˤ���, UART1 ���|�ʧ@
	P1 = 0xFF;
	P1AIO = 0x00;		//Port pin has digital and analog input
	P2M0 = 0xFF;		//P2 as push-pull mode
	P2 = 0xFF;
	P3M0 = 0x30;		//P3.7 P3.6 P3.3 P3.2 P3.1 P3.0 as open drain mode, others as push-pull mode
						//���չL, P3.6��P3.7 �@�w�n�]�wopen drain mode, nWR / nRD �~�ॿ�T�ʧ@. 
						//�]�wSTRETCH 	�վ����, ���LA �����^��nWR / nRD �S���v�T. 
							
	P4M0 = 0x7F;		//P4 as push-pull mode

	SFR_Page0;
	P5M0 = 0xFF;		//P5 as push-pull mode
	SFR_Page1;

	P6M0 = 0xFF;		//P6 as push-pull mode
	
	PUCON0 = 0x03;		//P0PU1 = 1, P0PU0 = 1. (only enable Port0 open-drain pull high resistor)
	
	
	STRETCH = 0x22;	//ALE pulse = 3 SYSCLK, nWR / nRD pulse as 3 SYSCLK. Test ok 2014/2/3	 	

	SFR_Page0;
	UsbInit();
	SFR_Page1;
}
/*
void Select_InternalXRAM()
{
	EA = 0;		//�����������_, �H�K�ñ�.
	EnInternalXRAM;
	ExRamSelect = InternalXRAM;
	EA = 1;
}

void Select_ExternalXRAM()
{
	EA = 0;		//�����������_, �H�K�ñ�.
	ExRamSelect = ExternalXRAM;
	DisInternalXRAM;
	EA = 1;
}
*/

void Select_CPLD1()
{
	Byte temp = 10;
	
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23

	MCU_A_23 = 1;
	MCU_A_22 = 0;
	MCU_A_21 = 0;
	MCU_A_20 = 0;
	
	while(temp --)
	{
			
	}
}



void Select_CPLD2()
{
	Byte temp = 10;
	
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23

	MCU_A_23 = 0;
	MCU_A_22 = 0;
	MCU_A_21 = 0;
	MCU_A_20 = 0;
	
	while(temp --)
	{
			
	}
}

void Select_ISA_Bus()
{
	Byte temp = 10;

	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23

	MCU_A_23 = 0;
	MCU_A_22 = 0;
	MCU_A_21 = 0;
	MCU_A_20 = 1;
			
	while(temp--)
	{
			
	}
}



void Select_SRAM_0()
{
	Byte temp = 10;
		
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23

	MCU_A_23 = 1;
	MCU_A_22 = 0;
	MCU_A_21 = 0;
	MCU_A_20 = 1;
			
	while(temp--)
	{
			
	}	
}

void Select_SRAM_1()
{
	Byte temp = 10;

	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23
	MCU_A_23 = 1;
	MCU_A_22 = 0;
	MCU_A_21 = 1;
	MCU_A_20 = 0;	
		
	while(temp--)
	{
			
	}
}

void Select_SRAM_2()
{
	Byte temp = 10;
		
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23

	MCU_A_23 = 1;
	MCU_A_22 = 0;
	MCU_A_21 = 1;
	MCU_A_20 = 1;
				
	while(temp--)
	{
			
	}
}

void Set_SRAM_HighAddress(Byte Add)
{
	Byte temp = 10;
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_16 ~ MCU_A_19
	
	if(Add & 0x01)
	{
		MCU_A_16 = 1;
	}
	else
	{
		MCU_A_16 = 0;
	}

	if(Add & 0x02)
	{
		MCU_A_17 = 1;
	}
	else
	{
		MCU_A_17 = 0;
	}

	if(Add & 0x04)
	{
		MCU_A_18 = 1;
	}
	else
	{
		MCU_A_18 = 0;
	}

	if(Add & 0x08)
	{
		MCU_A_19 = 1;
	}
	else
	{
		MCU_A_19 = 0;
	}
	
	while(temp--)
	{
		
	}
	
}


void Write_DO(Byte DO_L, Byte DO_H)		//�g�J10031-A2 �M�Ϊ�DO �I
{
	Byte temp = 10;
		
		
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23
	//1100 : DO 7:0

	MCU_A_23 = 1;
	MCU_A_22 = 1;
	MCU_A_21 = 0;
	MCU_A_20 = 0;
	
	while(temp--)
	{
			
	}
	USBInterruptOff;
	ExternalXRAM;
	XBYTE[0xFFFF] = DO_L;
	InternalXRAM;
	USBInterruptOn;
	temp = 10;
		
	//1101 : DO 15:8
	MCU_A_23 = 1;
	MCU_A_22 = 1;
	MCU_A_21 = 0;
	MCU_A_20 = 1;
				
	while(temp--)
	{
			
	}
	USBInterruptOff;
	ExternalXRAM;
	XBYTE[0xFFFF] = DO_H;
	InternalXRAM;
	USBInterruptOn;
}

void Read_DI()
{
	Byte temp = 10;
		
	SFR_Page1;		//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23
		
	MCU_A_23 = 1;
	MCU_A_22 = 1;
	MCU_A_21 = 1;
	MCU_A_20 = 0;
			
	while(temp--)
	{
			
	}
	USBInterruptOff;
	ExternalXRAM;
	DI_L = XBYTE[0xFFFF];		
	InternalXRAM;
	USBInterruptOn;
	DI_L = 0xFF - DI_L;		//���ϦV

	SFR_Page1;
		
	MCU_A_23 = 1;
	MCU_A_22 = 1;
	MCU_A_21 = 1;
	MCU_A_20 = 1;
				
	temp = 10;
	while(temp--)
	{
			
	}
	USBInterruptOff;
	ExternalXRAM;
	DI_H = XBYTE[0xFFFF];		//���ϦV
	DI_H = 0xFF - DI_H;
	InternalXRAM;
	USBInterruptOn;
}

void CPLD2_CtrlReg(Byte Value)
{
	Byte temp = 10;
	
	SFR_Page1;			//�n���SFR_Page1 �~��s�� MCU_A_20 ~ 23
		
	MCU_A_23 = 0;
	MCU_A_22 = 0;
	MCU_A_21 = 0;
	MCU_A_20 = 0;			
	while(temp--)
	{
			
	}
	USBInterruptOff;
	ExternalXRAM;
	XBYTE[0xFFFF] = Value;
	InternalXRAM;
	USBInterruptOn;
}

/*
Byte Read_ISA_Bus(Word Add)
{
	Byte ReturnValue;
	
	Select_ISA_Bus();		//�]�wMCU_A_23 : 20, �B���ExternalXRAM
		
	ReturnValue = XBYTE[Add];	

	return ReturnValue;
	
}
*/

/*
void Write_ISA_Bus(Word Add, Byte Value)
{
	Select_ISA_Bus();	//�]�wMCU_A_23 : 20, �B���ExternalXRAM
	
	XBYTE[Add] = Value;
		
}
*/

/*
void BackToOriginalXRAM()
{
	EA = 0;
	if(ExRamSelect == InternalXRAM)	//���InternalXRAM
	{
		EnInternalXRAM;
	}
	else		//���ExternalXRAM
	{
		DisInternalXRAM;
	}
	
	EA = 1;
}
*/


void Delay_ms(DWord DelayTime)
//�o��n��{�H���_�p�⪺ms ����. �{�b���ʲ���
{
	Byte temp = 1000;
	
	while(DelayTime--)
	{
		while(temp --)
		{
			
		}
	}	
}

/*************************************************************************************


*************************************************************************************/

void SetFunctionToSram()//�NFLASH ��Single Motion Profile �M Motion Profile �h�� SRAM �� Single Motion Profile �M Motion Profile
{							
	Word idata index;
	long BaseNow = 0;
	Byte idata DBuf = 0,DBuf1 = 0 ;
	
	MX25L_SR(0, 0);
	USBInterruptOff;
	ExternalXRAM;
/*	Motion & Trigger Profile Set	*/	
	Select_SRAM_0();	//���SRAM0. SFR_PAGE1
	for(index = 0; index <= 0x8ff;index++ )		
	{
		DBuf = XBYTE[0x2000 + index];
		XBYTE[0x0000 + index] = DBuf;
	}
	
/*	Single Motion Profile Set	*/
	for(index = 0x900; index <= 0xfff; index++ ) 
	{										 
		DBuf = XBYTE[0x2000 + index];		 
		XBYTE[ index] = DBuf;
	}
	MX25L_SR(0, 1);							
	USBInterruptOff;
	ExternalXRAM;
	Select_SRAM_0();
	Set_SRAM_HighAddress(0);
	for(index = 0; index <= 0x1ff; index++ )
	{		
		DBuf = XBYTE[0x2000 + index];	
		XBYTE[0x1000 + index] = DBuf;
	} 
/*		Press & OK/NG	Profile				*/	
	MX25L_SR(0, 4);	
	USBInterruptOff;
	ExternalXRAM;
	Select_SRAM_0();
	Set_SRAM_HighAddress(0);
	for(index = 0;index <= 0x05FF;index++)
	{
		DBuf = XBYTE[0x2000 + index];	
		XBYTE[0x4000 + index] = DBuf;
	}	
	
/*  Machine Profile  Set  */
	MX25L_SR(0, 2);
	USBInterruptOff;
	ExternalXRAM;
	Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  	Set_SRAM_HighAddress(0);
	DBuf = XBYTE[0x2000 + 4];
    DBuf &= 0x0f;
	if(DBuf == 0x0f)		//Encoder_0_INC_CtrlReg 
	{
		DBuf = XBYTE[0x2000 + 7];		//�Ǭq�{��2015/3/16�קאּŪ�^write current position����m
		Select_ISA_Bus();
		XBYTE[0x58D] = 0x00;
		XBYTE[0x58E] = 0x00;
		XBYTE[0x58F] = DBuf;
		/*Select_SRAM_0();				//�ϥγo�q�}����|Ū�^�W����������m,�Ӥ��O8388608
		Set_SRAM_HighAddress(0);
		DBuf = XBYTE[0x4000 + CurrentPositionAddress ];
		Select_ISA_Bus();
		XBYTE[0x58D] = DBuf;
		Select_SRAM_0();
		DBuf =  XBYTE[0x4000 + CurrentPositionAddress + 1];
		Select_ISA_Bus();
		XBYTE[0x58E] = DBuf;
		Select_SRAM_0();
		DBuf =  XBYTE[0x4000 + CurrentPositionAddress + 2];
		Select_ISA_Bus();
		XBYTE[0x58F] = DBuf;*/
		
		Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  		Set_SRAM_HighAddress(0);
		DBuf = XBYTE[0x2000 + 4];
		DBuf = DBuf >> 6;
		InternalXRAM;
		USBInterruptOn;
		DBuf = EncoderCtrlRegSet[DBuf];
		USBInterruptOff;
		ExternalXRAM;
		Select_ISA_Bus();
		XBYTE[0x562] = 3;		
		XBYTE[0x563] = DBuf;
		Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  		Set_SRAM_HighAddress(0);
	}
	else
	if((DBuf == 0x00) || (DBuf == 0x01) || (DBuf == 0x02) || (DBuf == 0x03))//Encoder_0_ABS_CtrlReg
	{
		DBuf1 = XBYTE[0x2000 + 7];
		Select_ISA_Bus();
		XBYTE[0x5A8] = 0x00;
		XBYTE[0x5A9] = 0x00;
		XBYTE[0x5AA] = DBuf1;
		Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  		Set_SRAM_HighAddress(0);
		DBuf = XBYTE[0x2000 + 4];		
		DBuf1 = DBuf >> 6;
		DBuf = DBuf & 0x03;
		InternalXRAM;
		USBInterruptOn;
		DBuf = EncoderABSCtrlReg[DBuf][DBuf1];
		USBInterruptOff;
		ExternalXRAM;
		Select_ISA_Bus();
		XBYTE[0x562] = 0x14;		
		DBuf1 = XBYTE[0x563];
		DBuf = (DBuf1 & 0xf0) | DBuf;
		XBYTE[0x562] = 0x14;
		XBYTE[0x563] = DBuf;
		Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  		Set_SRAM_HighAddress(0);
	}
	
	DBuf = XBYTE[0x2000 + 8];	//Encoder1CtrlReg 
	DBuf1 = XBYTE[0x2000 + 9];	//Encoder2CtrlReg 
	Select_ISA_Bus();
	XBYTE[0x5A2] = 0x00;
	XBYTE[0x5A3] = 0x00;
	XBYTE[0x5A4] = DBuf;
	XBYTE[0x5A5] = 0x00;
	XBYTE[0x5A6] = 0x00;
	XBYTE[0x5A7] = DBuf1;
	Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  	Set_SRAM_HighAddress(0);
	DBuf = XBYTE[0x2000 + 5];
	DBuf1 = XBYTE[0x2000 + 6];
	DBuf = DBuf >> 6;
	DBuf1 = DBuf1 >> 6;
	InternalXRAM;
	USBInterruptOn;
	DBuf = EncoderCtrlRegSet[DBuf];
	DBuf1 = EncoderCtrlRegSet[DBuf1];
	USBInterruptOff;
	ExternalXRAM;
	Select_ISA_Bus();
	XBYTE[0x562] = 0x04;	//Encoder1CtrlReg 
	XBYTE[0x563] = DBuf;
	XBYTE[0x562] = 0x05;	//Encoder2CtrlReg 
	XBYTE[0x563] = DBuf1;
	
/***************************************
���եζ}����@�U���ʧ@��
�i�H���������䱱��Single Profile
***************************************/
	XBYTE[0x562] = 0;		//SRAM Infinite State Machine Enable��~�i�Ϋ��䱱��
	DBuf = XBYTE[0x563];	  
	DBuf |= 0x01;
	XBYTE[0x562] = 0;
	XBYTE[0x563] = DBuf; 
/***************************/	
	Select_SRAM_0();	//���SRAM0. SFR_PAGE1
  	Set_SRAM_HighAddress(0);
	InternalXRAM;
	USBInterruptOn;
}
