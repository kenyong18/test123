//******************************************************************************//
//					Autolutiontech												//
//																				//
//			task.h																//
//																				//
//			Version 1.0															//
//																				//
//			Author: Frank Wang													//
//																				//
//			Date: 2014/02/02													//
//																				//
//******************************************************************************//


#ifndef _TASK_H_
#define _TASK_H_

#include "main.h"

//以下定義System Command 指令編號
#define SysCom_EmgStop						0x00
#define	SysCom_WriteMotionProfile			0x01
#define SysCom_WriteTriggerProfile			0x02
#define SysCom_WriteSequentialCommand		0x03
#define SysCom_WriteSingleMotionProfile		0x04
#define SysCom_WriteMachineProfile			0x05
#define SysCom_ReadMotionProfile			0x06
#define SysCom_ReadTriggerProfile			0x07
#define SysCom_ReadSequentialCommand		0x08
#define SysCom_ReadSingleMotionProfile		0x09
#define SysCom_ReadMachineProfile			0x0A
#define SysCom_ExeSequentialCommand			0x0B
#define SysCom_ExeSingleMotionProfile		0x0C
#define SysCom_WriteOKNG_Criteria			0x0D
#define SysCom_PauseSequentialCommand		0x0E
#define SysCom_ResumeSequentialCommand		0x0F
#define SysCom_StopSequentialCommand		0x10
#define SysCom_ExeMotionProfile				0x11
#define SysCom_WritePressProfile			0x12
#define SysCom_ReadPressProfile				0x13
#define SysCom_WriteCurrentPosition			0x14
#define SysCom_ClearOKNGAllMomeoryOrWriteFlash 0x15
#define SysCom_WriteOKNGtoSram				0x16
#define SysCom_ReadOKNG						0x17

#define SysCom_EraseFlash					0x30		//Chip Erase Command
#define SysCom_EraseSector					0x31		//

#define SysCom_ReadISABus					0x40
#define SysCom_WriteISABus					0x41
#define SysCom_ReadISABus_Ex				0x42
#define SysCom_WriteISABus_Ex				0x43
#define SysCom_Read_0x562					0x44
#define SysCom_Write_0x562					0x45
#define SysCom_Read_0x564					0x46
#define SysCom_Write_0x564					0x47

#define SysCom_SeqUploadState				0x60
#define SysCom_SeqUploadData                0x61
#define SysCom_SeqRealTimeUploadData		0x62

//以下定義控制器回傳PC的指令編號
#define ReadData_VersionNumber				0x00
#define ReadData_ControllerStatus			0x01

#define ReadData_MotionProfile				0x10
#define ReadData_TriggerProfile				0x11
#define ReadData_SequentialCommand			0x12

#define ReadData_ReadISABus					0x40
#define ReadData_ReadISABus_Ex				0x42
#define ReadData_Read_0x562					0x44
#define ReadData_Read_0x564					0x46

//以下定義ProgramStatus
#define ProgramStatus_Stop					0x00
#define ProgramStatus_Run					0x01
#define ProgramStatus_Pause					0x02
#define ProgramStatus_Resume				0x03
#define ProgramStatus_PrepareToStop			0x04
#define ProgramStatus_PrepareToPause		0x05


//以下定義Sequential Command 
#define SeqCom_Reset						0x00
#define SeqCom_SelectMotionProfile			0x01
#define SeqCom_SelectTriggerProfile			0x02
#define SeqCom_ExeMotionProfile				0x03
#define SeqCom_SetTimer						0x04
#define SeqCom_StartTimer					0x05
#define SeqCom_StopTimer					0x06
#define SeqCom_ClearTimer					0x07
#define SeqCom_SetDO						0x08
#define SeqCom_SetCounter					0x09
#define SeqCom_StartCounter					0x0A
#define SeqCom_StopCounter					0x0B
#define SeqCom_ResetBoardTimer				0x0D
#define SeqCom_StartBoardTimer				0x0E
#define SeqCom_StopBoardTimer				0x0F
#define SeqCheckOKNG						0x10
#define SeqCom_SetTempValue					0x11
#define SeqCom_AddTempValue					0x12
#define SeqCom_RunStartPosition				0x13

#define SeqCom_WaitUntil					0x20
#define SeqCom_IfThenElse					0x21
#define SeqCom_ForLoop						0x22
#define SeqCom_Goto							0x23

#define SeqCom_UploadTestData				0x30
#define SeqWiteCurrentPosition				0x31
#define SeqCom_EOF						    0xFE
#define SeqCom_NOP							0xFF


#define WaitUntil_Criteral_Not_Set						0x0000	//尚未設定等待事件
#define WaitUntil_Z_Axis_MotionDone_or_Stop				0x0001	//等待Z軸Motion Done 或 Stop
#define WaitUntil_X_Axis_MotionDone_or_Stop				0x0002	//等待X軸Motion Done 或 Stop
#define WaitUntil_Y_Axis_MotionDone_or_Stop				0x0003	
#define WaitUntil_Z_Axis_MotionDown_or_Stop_or_Error	0x0004
#define WaitUntil_X_Axis_MotionDown_or_Stop_or_Error	0x0005
#define WaitUntil_Y_Axis_MotionDown_or_Stop_or_Error	0x0006
#define WaitUntil_Timer_0_Expire						0x0007

#define WaitUntil_NewTestCommand_From_RS232				0x0020

#define CompareLogic_Equal			0		//A = B
#define CompareLogic_Big			1		//A > B
#define CompareLogic_Less			2		//A < B

#define DeferredCommand_NoCommand		0x00
#define DeferredCommand_UploadData		0x01

#define MotionProfileAddress		0x0000		//存放在SRAM_0 內的位址
#define TriggerProfileAddress		0x0800		//存放在SRAM_0 和 FLASH_0內的位址一樣

#define SingleMotionProfileAddress	0x0900	    //存放在SRAM_0 內的位址
#define SequentialCommandAddress	0x3000		//Sequential Command 存放在SRAM_0 內的位址
#define MachineProfileAddress		0x2000

#define OK_NGProfileAddress			0x4000		//OK/NG Profile的位址
#define CurrentPositionAddress		0x0400		//當前位置
#define PressProfileAddress			0x0500		//Press Profile

#define dUploadInterval	300						//interval 0.3s


#define dOrigin	8388608

enum											//機台按鍵高中低(上,下)
{ 
	ExKeyStart  = 0x02,
	ExKeyStop	= 0x01,
	ExKeyHighUp = 0x08,
	ExKeyHighDown = 0x04,
	ExKeyMidUp = 0x20,
	ExKeyMidDown = 0x10,
	ExKeyLowUp = 0x80,
	ExKeyLowDown = 0x40
};


extern Byte code PacketMask[][2];
extern Byte idata UploadState1,UploadState2,UploadState3;
extern Byte idata ProgramStatus;
extern Byte idata ProgramCounter;
extern Byte idata SequentialCommand;
extern Byte idata CommandParameters[4];
extern DWord idata TempValue[4];
//extern Byte bdata DeferredCommand;

extern Byte idata SelectedMotionProfile;
extern Byte idata SelectedSingleMotionProfile;

extern Word idata WaitUntilCriteria;

extern void Task_Process_SystemCommand();
extern void Task_Process_SequentialCommand();
extern void Task_Process_OtherEvents();
extern void Task_Process_DeferredCommand();

extern void SoftPLC_Init();

extern bit TimeroutX1ms(DWord  X1ms);



#endif
