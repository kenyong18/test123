//******************************************************************************//
//					Autolutiontech												//
//																				//
//		Usb_Dsc.c																//
//																				//
//			Version 1.0															//
//																				//
//			Author: ken															//
//																				//
//			Date: 2015/03/9														//
//																				//
//******************************************************************************//
#include "EasyCOM.h"



Byte xdata USBTxBuf[256] _at_ 0x0800 ;
Byte xdata USBRxBuf[256] _at_ 0x0900 ;

Byte idata Usb_length;
bit USBReceFlag,Usb_TxFinish;
//-----Device Descriptor-----//
code BYTE DEVICE_DESCRIPTOR[]=
{ 
	0x12,                                        // 0:  bLength
    0x01,                                        // 1:  bDescriptorType (Device)
    0x10,                                        // 2:  bcdUSB(LSB)
    0x01,                                        //     bcdUSB(MSB)
    0x02,                                        // 4:  bDeviceClass
    0x00,                                        // 5:  bDevice SubClass
    0x00,                                        // 6:  bDeviceProtocol
    0x08,                                        // 7:  bMaxPacketSize
    LOBYTE( USB_VID ),                           // 8:  idVendor(LSB)
    HIBYTE( USB_VID ),                           //     idVendor(MSB)
    LOBYTE( USB_PID ),                           // 10: idProduct(LSB)
    HIBYTE( USB_PID ),                           //     idProduct(MSB)
    LOBYTE( USB_DID ),                           // 12: bcdDevice(LSB)
    HIBYTE( USB_DID ),                           //     bcdDevice(MSB)
  #ifdef MF_STRING
    0x01,                                        // 14: iManufacture (String Index)
  #endif
  #ifndef MF_STRING
    0x00,                                        // 14: iManufacture (String Index)
  #endif
  #ifdef PD_STRING
    0x02,                                        // 15: iProduct     (String Index)
  #endif
  #ifndef PD_STRING
    0x00,                                        // 15: iProduct     (String Index)
  #endif
  #ifdef SN_STRING    
    0x03,                                        // 16: iSerialNumber(String Index)
  #endif
  #ifndef SN_STRING    
    0x00,                                        // 16: iSerialNumber(String Index)
  #endif
    0x01                                         // 17: bNumConfigurations
};

code BYTE LANGUAGEID_DESCRIPTOR[]=
  { 
	0x04,					 // Computed by subtraction two from the value of the first byte of the descriptor
    0x03, 					 // Descriptor Type
    0x09,
    0x04
  };
#define MFS_LEN sizeof("Autolution Technology Inc.")*2
//-----MANUFACTURER(UNICODE) in String Descriptor-----//
  code BYTE MANUFACTURER_DESCRIPTOR[]=
  { 
	MFS_LEN,
    0x03,                                        // Descriptor Type
    'A',0x00,
    'u',0x00,
    't',0x00,
    'o',0x00,
    'l',0x00,
    'u',0x00,
    't',0x00,
    'i',0x00,
    'o',0x00,
    'n',0x00,
    ' ',0x00,
    'T',0x00,
    'e',0x00,
    'c',0x00,
    'h',0x00,
    'n',0x00,
    'o',0x00,
    'l',0x00,
    'o',0x00,
    'g',0x00,
    'y',0x00,
    ' ',0x00,
    'I',0x00,
    'n',0x00,
    'c',0x00,
    '.',0x00
  };
#define PDS_LEN sizeof("10031_A2 USB EasyCOM")*2
//-----PRODUCT(UNICODE) in String Descriptor-----//
code BYTE PRODUCT_DESCRIPTOR[] =
  { 
	PDS_LEN,
    0x03,                                        // Descriptor Type
    '1',0x00,
    '0',0x00,
    '0',0x00,
    '3',0x00,
    '1',0x00,
    '_',0x00,
    'A',0x00,
    '2',0x00,	
    ' ',0x00,
    'U',0x00,
    'S',0x00,
    'B',0x00,
    ' ',0x00,
    'E',0x00,
    'a',0x00,
    's',0x00,
    'y',0x00,
    'C',0x00,
    'O',0x00,
    'M',0x00
  };
#define SNS_LEN sizeof("621031")*2
//-----Serial Number in String Descriptor-----//
  code BYTE SERIALNUMBER_DESCRIPTOR[]=
  { 
	SNS_LEN,
    0x03,                                        // Descriptor Type
    '6',0x00,
    '2',0x00,
    '1',0x00,
    '0',0x00,
    '3',0x00,
    '1',0x00
  };
  
/*
void USB_Event( void )                           // Do not remove
{ 
	if( UsbEvent.Suspend == SET )               // Power down event from HOST
	{ 
		UsbEvent.Suspend = CLR;// To do..
		UsbEvent.WakeUp = SET;
	}
	if( UsbEvent.WakeUp == SET )                // MCU wakeup already
	{
		UsbEvent.WakeUp = CLR;// To do..
	}
	if( UsbEvent.Reset == SET )                 // Reset event from HOST
	{ 
		UsbEvent.Reset = CLR;        // To do..
	}
	if( UsbEvent.EmuOK == SET )                 // USB enumeration OK
	{
			
	}
}*/

//=========================================================
//  USB export  function
//=========================================================
void UsbInit()
{
	Initial();
	USBReceFlag = 0;
	Usb_TxFinish = 0;
}
//receiver data
//=========================================================
BYTE UsbReceiverComplete()
{
	BYTE idata i,index = 0,PacketMax = 0,PacketState = 0,RecordPacketState = 0xff,RecordCmd = 0xff;
	WORD idata TmOut ;
	while(InFlag == 1)
	{
		InternalXRAM;			//�ϥ�on-chip xram	
		USB_Read_Data_Complete();
		
		if(InBuffer[2] == 0)
		{		
			if((InBuffer[1] > 61) && (InBuffer[1] < 253))
			{
				PacketState = 1;
				RecordPacketState = 0;
				if(InBuffer[1] < 123) PacketMax = 2;
				else if(InBuffer[1] < 184) PacketMax = 3;
				else if(InBuffer[1] < 245) PacketMax = 4;
				else if(InBuffer[1] < 253) PacketMax = 5;
				else
				{
					break;	
				}
			}
			else
			{
				PacketState = 0;
			}
			for(i = 0;i < 64;i++)
			{
		   		USBRxBuf[index++] = InBuffer[i];
		   	}
			RecordCmd = InBuffer[0];
		}
		else
		{
			if(InBuffer[2] == RecordPacketState)
			{
			    for(i = 3;i < 64;i++)
				{				
			   		USBRxBuf[index++] = InBuffer[i];
			   	}
				PacketState++;
			}
			else
			{
				break;
			}
		}
		if(InBuffer[0] !=  RecordCmd) break;
		if(PacketState == 0)
		{
			USBReceFlag = 1;
			return USBRxBuf[0];
		}			
		if(PacketState == PacketMax)
		{  
			USBReceFlag = 1;
			return USBRxBuf[0];		
		}		

		TmOut = 10000;//TmOut = 100;
		while(InFlag == 0)
		{
			Delay(5);//Delay(5000);
			if((--TmOut) == 0)
			{
				USBReceFlag = 0;
				return (USBRxBuf[0] = 0xff);//return _length;
			}
		}
		RecordPacketState++;
	}
	USBReceFlag = 0;
	return (USBRxBuf[0] = 0xff);//return _length;
}
//send data	set length  flag
//=========================================================
void Usb_Tx(BYTE idata _length)
{
	Usb_length = _length + 3;
 	Usb_TxFinish = 1;
}
//send data
//=========================================================
void UsbTransmit()
{
	BYTE idata PacketNo = 0,PacketNoLimit = 1;
	WORD _TmOut = 20000;
	
	InternalXRAM;			//�ϥ�on-chip xram	
	if(UsbEventState() == 1)
	{
		USBTxBuf[2] = PacketNo ;
		if(Usb_length <= 64) PacketNoLimit =1;
		else if(Usb_length <= 125) PacketNoLimit = 2;
		else if(Usb_length <= 186) PacketNoLimit = 3;
		else PacketNoLimit = 4;
		while(PacketNo < PacketNoLimit)
		{		
			switch(PacketNo)
			{
			case 0:
				if(Usb_length < 65)
				{
					USB_Send_Data_To_PC(Usb_length,USBTxBuf+(61*PacketNo));
				}
				else
				{
					USB_Send_Data_To_PC(64,USBTxBuf+(61*PacketNo));
				}
				break;
			case 1:
				if(Usb_length < 125)
				{
					USB_Send_Data_To_PC(Usb_length-61,USBTxBuf+(61*PacketNo));
				}
				else
				{
					USB_Send_Data_To_PC(64,USBTxBuf+(61*PacketNo));
				}				
				break;
			case 2:
				if(Usb_length < 186)
				{
					USB_Send_Data_To_PC(Usb_length-122,USBTxBuf+(61*PacketNo));
				}
				else
				{
					USB_Send_Data_To_PC(64,USBTxBuf+(61*PacketNo));
				}
				break;
			case 3:	
				if(Usb_length < 247)
				{
					USB_Send_Data_To_PC(Usb_length-183,USBTxBuf+(61*PacketNo));			
				}
				else
				{
					USB_Send_Data_To_PC(64,USBTxBuf+(61*PacketNo));	
				}
				break;
			default:
				break;
			}
			PacketNo++;
			USBTxBuf[61 * PacketNo] = USBTxBuf[0];
			USBTxBuf[(61 * PacketNo)+1] = USBTxBuf[1];
			USBTxBuf[(61 * PacketNo)+2] = PacketNo;
			if((--_TmOut) == 0) break;
		}
	}
}
//uart state
//=========================================================
void UsbUartState(BYTE _state)
{
	USB_Send_UartState_To_PC(_state);
}
//
//=========================================================
BYTE UsbEventState()
{
	if( UsbEvent.Suspend == SET )               // Power down event from HOST
	{ 
		UsbEvent.Suspend = CLR;// To do..
		UsbEvent.WakeUp = SET;
		UsbEvent.EmuOK =  CLR;
		return 0;
	}
	if( UsbEvent.WakeUp == SET )                // MCU wakeup already
	{
		UsbEvent.WakeUp = CLR;// To do..
		return 2;
	}
	if( UsbEvent.Reset == SET )                 // Reset event from HOST
	{ 
		UsbEvent.Reset = CLR;// To do..
		return 0;
	}
	if( UsbEvent.EmuOK == SET )                 // USB enumeration OK
	{
		return 1;	
	}
}

