//******************************************************************************//
//					Autolutiontech												//
//																				//
//			SPI.c																//
//																				//
//			Version 1.0															//
//																				//
//			Author: Frank Wang													//
//																				//
//			Date: 2014/11/24													//
//																				//
//******************************************************************************//


#include "SPI.h"

//Byte idata SPI_TempData[3];

void SPI_Init()
{
//SPR0 ~ SPR2 = "000". (SPI Clock = SYSCLK / 4)
//CPOL = 0, CPHA = 0
//MSTR = 1 (as master)
//DORD = 0 (MSB First)
//SPEN = 1 (SPI Enable)
//SSIG = 1 (忽略nSS 信號.)
	SPCON = 0xD0;
	
//SPR2 = 0
//SPIBSY (read only)
//THRF (read only)
//WCOL	(忽略)
//SPIF (Read only)
	SPSTAT = 0xC0;
	
//	SPI_TempData[0] = 0;
//	SPI_TempData[1] = 0;
//	SPI_TempData[2] = 0;
	
}

/*
Byte SPI_IsTHRFBusy()
//若THRF = 1, 則回傳 1. 否則回傳 0
{
	if((SPSTAT & 0x20) > 0)
	{
		return 1;	//THRF == 1
	}
	else
	{
		return 0;	//THRF == 0
	}
	
}
*/

void SPI_ResetSPIF()
{
	SPSTAT |= 0x80;	//Write 1 to SPIF will reset SPIF
}

void SPI_WaitForSPIF()
//這裡會用while迴圈等待SPIF. 
{
	while((SPSTAT & 0x80) == 0)
	{
	}
	
	SPI_ResetSPIF();
}


void Flash_Select(Byte FlashNo)
{
//Flash_nCS 都在P5, 因此要存取前, 需切換SFR_PAGE 為0. 並且關閉UART 中斷. 
//要離開此function前, 再切換SFR_PAGE 為 11/24
//	Disable_UART_Interrupt();

	SFR_Page0;
	
	if(FlashNo == 0)	//Select Flash_0
	{
		P50 = 0;
		P51 = 1;
		P52 = 1;
	}
	else
	if(FlashNo == 1) 	//Select Flash_1
	{
		P50 = 1;
		P51 = 0;
		P52 = 1;
	}
	else	//Select Flash_2
	if(FlashNo == 2)
	{
		P50 = 1;
		P51 = 1;
		P52 = 0;
	}
	else	//all dis-select
	{
		P50 = 1;
		P51 = 1;
		P52 = 1;
	}	
	SFR_Page1;
//	Enable_UART_Interrupt();
}

/*
void MX25L_RDID()
//測試SPI介面用. 測試ok  2014/11/25
{
	Flash_Select(0);
	SPDAT = 0x9F;	//Command 0x9F / RDID
	
	SPDAT = 0x00;	//Get Manufacturer ID
	
	while((SPSTAT & 0x20) > 0)	//THRF = '1'
	{
	}
	SPDAT = 0x00;	//Device ID
	while((SPSTAT & 0x20) > 0) //THRF = '1'
	{
	}
	SPDAT = 0x00;	//Device ID
	Flash_Select(0xFF);
}
*/
void MX25L_WREN(Byte FlashNo)
{
	Flash_Select(FlashNo);
	SPI_ResetSPIF();
	SPDAT = 0x06;
	SPI_WaitForSPIF();
	Flash_Select(0xFF);	
}

/*
void MX25L_WRDI(Byte FlashNo)
{
	Flash_Select(FlashNo);
	SPI_ResetSPIF();
	SPDAT = 0x04;
	SPI_WaitForSPIF();
	Flash_Select(0xFF);
}
*/

/*
void MX25L_RDSR(Byte FlashNo)
{
	Flash_Select(FlashNo);
	
	SPI_ResetSPIF();
	SPDAT = 0x05;
	SPI_WaitForSPIF();
	SPDAT = 0x00;	//Read First Byte
	SPI_WaitForSPIF();
	SPI_TempData[0] = SPDAT;

	Flash_Select(0xFF);
}
*/

void MX25L_ContCheckWIP(Byte FlashNo)
//持續檢查Flash Status Register WIP(write in progress) bit. 直到WIP 為 '0' 才會離開
{
	Byte DataTemp;
	Flash_Select(FlashNo);
	SPI_ResetSPIF();
	SPDAT = 0x05;
	SPI_WaitForSPIF();
	
	do
	{
		SPDAT = 0x00;
		SPI_WaitForSPIF();
		DataTemp = SPDAT;
	}
	while((DataTemp & 0x01) == 1);
	
	Flash_Select(0xFF);
}

void MX25L_ContCheckWEL(Byte FlashNo)
//持續檢查Flash Status Register WEL(Write Enable Latch) bit. 直到WEL 為 '1' 才會離開
{
	Byte DataTemp;
	Flash_Select(FlashNo);
	SPI_ResetSPIF();
	SPDAT = 0x05;
	SPI_WaitForSPIF();
	do
	{
		SPDAT = 0x00;
		SPI_WaitForSPIF();
		DataTemp = SPDAT;
	}
	while((DataTemp & 0x02) == 0);	
	Flash_Select(0xFF);
}

void MX25L_ReadStart(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3)
//AD1 為 High Address, AD3 為 Low Address
{
	Flash_Select(FlashNo);
	
	SPI_ResetSPIF();
	SPDAT = 0x03;	//READ 
	SPI_WaitForSPIF();
	SPDAT = AD1;
	SPI_WaitForSPIF();
	SPDAT = AD2;
	SPI_WaitForSPIF();
	SPDAT = AD3;
	SPI_WaitForSPIF();
	
}

Byte MX25L_ContRead()
//前面必須先執行MX25L_ReadStart 指令
{
	
	SPDAT = 0x00;	//write 0x00
	SPI_WaitForSPIF();
	return SPDAT;
}

void MX25L_ReadWriteStop()
{
	Flash_Select(0xFF);
}

void MX25L_PageProgramStart(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3)
//AD1 為High address, AD3 為 Low Address
{
	Flash_Select(FlashNo);
	SPI_ResetSPIF();
	SPDAT = 0x02;	//Page Program Instruction
	SPI_WaitForSPIF();
	SPDAT = AD1;
	SPI_WaitForSPIF();
	SPDAT = AD2;
	SPI_WaitForSPIF();
	SPDAT = AD3;
	SPI_WaitForSPIF();
}

void MX25L_ContWrite(Byte Data)
{	
	SPDAT = Data;
	SPI_WaitForSPIF();
}

void MX25L_CE(Byte FlashNo)		//Chip Erase Command
{
	MX25L_WREN(FlashNo);	//先下 Write Enable 指令

	Flash_Select(FlashNo);

	SPI_ResetSPIF();
	SPDAT = 0x60;	//Chip Erase
	SPI_WaitForSPIF();	
	Flash_Select(0xFF);		
	
	MX25L_ContCheckWIP(0);	//等待WIP 結束	
}

void MX25L_SE(Byte FlashNo, Byte SectorNo)
//SectorNo : 0 ~ F. 離開時已經確定Write In Progress == '0'
{
	MX25L_WREN(FlashNo);
	Flash_Select(FlashNo);
	
	SPI_ResetSPIF();
	SPDAT = 0x20;						//Sector Erase
	SPI_WaitForSPIF();
	SPDAT = 0x00;
	SPI_WaitForSPIF();
	SPDAT = SectorNo << 4;
	SPI_WaitForSPIF();
	SPDAT = 0x00;
	SPI_WaitForSPIF();	
	Flash_Select(0xFF);					//Disable Chip select	
	MX25L_ContCheckWIP(FlashNo);
}

void MX25L_SR(Byte FlashNo, Byte SectorNo)	//結束時已經執行 Flash_Select(0xFF)
//對MX25L 執行Sector Read. 並且將資料搬到SRAM-0 的暫存區
//執行此函式前, 必須確認已經Disable UART Interrupt
{
	Byte AD2, DataTemp;
	Word DataIndex;
	Flash_Select(FlashNo);		
	
	USBInterruptOff;
	ExternalXRAM;
	Select_SRAM_0();
	Set_SRAM_HighAddress(0x00);			//設定MCU_A_19 : 16
	
	AD2 = SectorNo << 4;
	MX25L_ReadStart(FlashNo, 0, AD2, 0);
	for(DataIndex = 0; DataIndex < 4096; DataIndex ++)
	{
		DataTemp = MX25L_ContRead();
		XBYTE[0x2000 + DataIndex] = DataTemp;	//SRAM0 的 0x2000 ~ 0x2FFF 是Flash sector 專用暫存區
	}	
	MX25L_ReadWriteStop();
	InternalXRAM;						//切換存取內部XRAM
	USBInterruptOn;
//	Flash_Select(0xFF);	
}

void MX25L_SW(Byte FlashNo, Byte SectorNo)
//對MX25L 執行Sector Write. 並且將資料由SRAM-0 的暫存區 搬到Flash
//執行此函式前, 必須確認已經Disable UART Interrupt
{
	Byte AD2, DataTemp;
	Byte PageIndex, ByteIndex;
	Word DataIndex = 0;
	
	USBInterruptOff;
	ExternalXRAM;
	Select_SRAM_0();					//設定MCU_A_23 : 20
	Set_SRAM_HighAddress(0x00);			//設定MCU_A_19 : 16
	Flash_Select(FlashNo);

	for(PageIndex = 0; PageIndex < 16; PageIndex ++)
	{
		AD2 = (SectorNo << 4) + PageIndex;
		
		MX25L_WREN(FlashNo);			//8 clocks
		MX25L_ContCheckWEL(FlashNo);	//16 clocks
		MX25L_PageProgramStart(FlashNo, 0, AD2, 0);	//32 clocks
		
		for(ByteIndex = 0; ByteIndex < 255; ByteIndex ++)
		{
			DataTemp = XBYTE[FlashSectorImageAddress + DataIndex];		
			MX25L_ContWrite(DataTemp);	//8 clocks for each
			DataIndex ++;
		}
		
		DataTemp = XBYTE[FlashSectorImageAddress + DataIndex];
		MX25L_ContWrite(DataTemp);		//8 clocks
		DataIndex ++;
		MX25L_ReadWriteStop();			//Flash_nCS = '1'
		MX25L_ContCheckWIP(FlashNo);	
	}
	MX25L_ReadWriteStop();
	InternalXRAM;						//切換存取內部XRAM
	USBInterruptOn;
}