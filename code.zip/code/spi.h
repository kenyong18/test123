//******************************************************************************//
//					Autolutiontech												//
//																				//
//			spi.h																//
//																				//
//			Version 1.0															//
//																				//
//			Author: Frank Wang													//
//																				//
//			Date: 2014/11/24													//
//																				//
//******************************************************************************//


#ifndef _SPI_H_
#define _SPI_H_
//參考MG82FG5A64 規格書 P133


#include "main.h"

#define FlashSectorImageAddress		0x2000		//Flash Sector image 存放在SRAM_0 內的位置


//extern Byte idata SPI_TempData[3];

extern void SPI_Init();		//SPI 介面初始化
extern void Flash_Select(Byte FlashNo);		//選擇要存取的Flash 編號.
//extern Byte SPI_IsTHRFBusy();	//檢查THRF bit 是否為 '1'. 已經實現, 但沒用到.
extern void SPI_ResetSPIF();	//Reset SPIF
extern void SPI_WaitForSPIF();	//等待SPIF = '1'. 等到之後, 會reset SPIF

/*
以下是針對MX25L 系列Flash 的function.
MX25L 系列flash, 最快存取Clock 為 33Mhz.
*/
extern void MX25L_WREN(Byte FlashNo);	//對MX25L 寫入 Write Enable Command
//extern void MX25L_WRDI(Byte FlashNo);	//對MX25L 寫入 Write Disable Command. 已經實現, 但沒用到
//extern void MX25L_RDID();	//對MX25L 寫入 Read ID Command. 測試SPI介面用. 測試ok
//extern void MX25L_RDSR(Byte FlashNo);	//對MX25L 寫入 Read Status Register Command. 這個函式有實現, 但發現好像沒什麼用途
//extern void MX25L_WRSR(Byte FlashNo);	//對MX25L 寫入 Write Status Register Command. 這個函式沒實現. 沒用途. 
extern void MX25L_ContCheckWIP(Byte FlashNo);	//持續檢查MX25L 的Status Register, 直到 WIP bit 為 '0' 才會離開
extern void MX25L_ContCheckWEL(Byte FlashNo);	//持續檢查MX25L 的Status Register, 直到 WEL bit 為 '1' 才會離開


//Read 的程序, 必須先下ReadStart 指令, 然後用ContRead 函式連續讀取資料, 最後用ReadStop 結尾
extern void MX25L_ReadStart(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3);	//對MX25L 寫入 Read Data 指令. 
extern Byte MX25L_ContRead();
extern void MX25L_FastRead(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3, Byte Dummy);	//對MX25L 寫入 Fast Read 指令
extern Byte MX25L_ContRead();
extern void MX25L_ReadWriteStop();	//僅設定ChipSelect high.

extern void MX25L_RDSFDP(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3, Byte Dummy);	//對MX25L 寫入 Read SFDP Mode
extern void MX25L_SE(Byte FlashNo, Byte SectorNo);	//對MX25L 寫入 Sector Erase
extern void MX25L_BE(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3);	//對MX25L 寫入 block erase
extern void MX25L_CE(Byte FlashNo);	//對MX25L 寫入 chip erase

extern void MX25L_PageProgramStart(Byte FlashNo, Byte AD1, Byte AD2, Byte AD3);	//對MX25L 寫入 Page Program
extern void MX25L_ContWrite(Byte Data);

extern void MX25L_SW(Byte FlashNo, Byte SectorNo);	//對MX25L 執行Sector Write. 
/*
MX25L 這種serial Flash, PageProgram寫入時, 僅能將bit 狀態由1 轉為 0 . 無法將bit 由0 轉為 1
因此PP時, 整個page 的bit都必須是 1, 才能寫入正確資料, 否則資料會是錯誤的. 
為了確保上述條件, 執行pp時, 必須先執行erase. 但MX25L erase的最小單位是 sector (4096 bytes = 16 page).
若要不影響其他page的資料, 則必須將所屬sector 資料讀出放在外部SRAM, 做成image. 接著修改外部SRAM的資料
-> 執行sector erase, -> 再將整個sector 的SRAM image 寫入. 
原本datasheet 並不支援Sector Write 指令. 這個指令必須由MCU 韌體實現. 
Step. 1 : 將整個Sector 資料搬出, 放在外部SRAM. (MX25L_SR 函式)
Step. 2 : 針對要修改的位置, 修改外部SRAM的資料. 
Step. 3 : 執行sector Erase. 將bit 全部重置為 '1'
Step. 4 : 執行MX25L_SW 函式. 將整個SRAM sector image 完整寫入. 
*/

extern void MX25L_SR(Byte FlashNo, Byte SectorNo);	//對MX25L 執行Sector Read. 並且將資料搬到SRAM-0 的暫存區




//extern void MX25L_DP(Byte FlashNo);	//對MX25L 寫入 Deep power down. 10031-A2 不需實作
//extern void MX25L_RDP();	//對MX25L 寫入 Release from deep power down. 10031-A2 不需實作
//extern void MX25L_RES();	//對MX25L 寫入 Read Electronic ID. 10031-A2 不需實作
//extern void MX25L_REMS();	//對MX25L 寫入 Read Electronic Manufacturer & Device ID. 10031-A2 不需實作





#endif

