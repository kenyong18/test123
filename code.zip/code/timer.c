//******************************************************************************//
//					Autolutiontech												//
//																				//
//			Timer.c																//
//																				//
//			Version 1.0															//
//																				//
//			Author: Frank Wang													//
//																				//
//			Date: 2014/11/09													//
//																				//
//******************************************************************************//


#include "Timer.H"

Word idata TimerCurrentValue[TimerNumber];
//Byte bdata TimerRun[2];
//Byte bdata TimeOut[2];
Word idata CounterTime = 0;
Byte bdata TimeFlag = 0;

Byte bdata TimerRun[1];
Byte bdata TimeOut[1];

void SoftTimer_Init()
/*
初始化軟體Timer. 此軟體Timer 以HW Timer3 為基礎, 每 1ms 計數一次
*/
{
	Byte temp;
	for(temp = 0; temp < TimerNumber; temp ++)
	{
		ReleaseTimer(temp);
	}
		
}

Byte GetAvailableTimer()
/*要使用Timer之前, 先執行此函式
//將Timer 改成僅剩兩組*/
{
	Byte temp;
/*
	for(temp = 0; temp < 8; temp ++)
	{
		if((TimerRun[0] & (0x01 << temp)) == 0)
		{
			return temp;
		}
	}
	
	for(temp = 0; temp < 8; temp ++)
	{
		if((TimerRun[1] & (0x01 << temp)) == 0)
		{
			return temp + 8;
		}
	}
*/

	for(temp = 0; temp < 2; temp ++)
	{
		if((TimerRun[0] & (0x01 << temp)) == 0)
		{
			return temp;
		}
	}	
}

void SetTimerTarget(Byte TimerNo, Word TimerValue)
{
	TimerCurrentValue[TimerNo] = TimerValue;
}

void TimerStart(Byte TimerNo)
//改成僅保留兩組Timer
{
/*	
	if(TimerNo < 8)
	{
		TimerRun[0] |= (0x01 << TimerNo);
	}
	else
	{
		TimerRun[1] |= (0x01 << TimerNo);
	}
*/
	if(TimerNo < 2)
	{
		TimerRun[0] |= (0x01 << TimerNo);
	}
}

Byte CheckTimerEvent(Byte TimerNo)
//改成僅保留兩組Timer
{
/*
	if(TimerNo < 8)
	{
		if(TimeOut[0] & (0x01 << TimerNo))
		{
			return 1;		//已經Timeout
		}
		else
		{
			return 0;		//尚未Timeout
		}
	}
	else
	{
		if(TimeOut[1] & (0x01 << TimerNo))
		{
			return 1;		//已經Timeout
		}
		else
		{
			return 0;		//尚未Timeout
		}
	}
*/
	if(TimerNo < 2)
	{
		if(TimeOut[0] & (0x01 << TimerNo))
		{
			return 1;		//已經Timeout
		}
		else
		{
			return 0;		//尚未Timeout
		}
	}
}

void ReleaseTimer(Byte TimerNo)
//修改之後, Firmware Timer 只保留2組
{
	Byte temp;
	EA = 0;

/*	if(TimerNo < 8)
	{
		temp = 0xFF - (0x01 << TimerNo);
		TimerRun[0] &= temp;
		TimeOut[0] &= temp;
	}
	else
	{
		temp = 0xFF - (0x01 << (TimerNo - 8));
		TimerRun[1] &= temp;
		TimeOut[1] &= temp;
	}	*/

	if(TimerNo < 2)
	{
		temp = 0xFF - (0x01 << TimerNo);
		TimerRun[0] &= temp;
		TimeOut[0] &= temp;
	}	
	EA = 1;
}

/*
void MG82FG5A64_Timer0_Init()
{
	
}
*/

/*
void MG82FG5A64_Timer1_Init()
{

}
*/
/*
void MG82FG5A64_Timer2_Init()
{
	SFR_Page0;

	
	SFR_Page1;
}
*/

void MG82FG5A64_Timer3_Init()
/*規格書 P-91
T3CON, T3MOD, T3X12, MG82FG5A64
RCAP3H, RCAP3L (Reload Value)
目前設定操作在16 bit timer, CLOCK = SYSCLK / 12; 
約1 ms 觸發中斷一次. Reload Value = 65536 - 922 = 64614
RCAL3H = 252, RCAP3L = 102*/
/*
T3CON, T3MOD, T3X12, MG84FG516
RCAP3H, RCAP3L (Reload Value)
目前設定操作在16 bit timer, CLOCK = SYSCLK / 12; 
約1 ms 觸發中斷一次. Reload Value = 65536 - 1000 = 64536
RCAL3H = 0xfc, RCAP3L = 0x18*/
{
	SFR_Page1;
	TR3 = 0;
	
	T3CON = 0x00;	//Timer Mode, TR3 = 0, 
	T3MOD = 0x00;	//T3 as 16-bit timer, Clock = SYSCLK/12, Disable T3 Clock output

	TH3 = 252;	//初始值
	TL3 = 102;	//初始值
	
	//RCAP3H = 252;
	//RCAP3L = 102;
	RCAP3H = 0xfc;
	RCAP3L = 0x18;
	
	EIE2 = 1;	//Enable Timer 3 interrupt
	TR3 = 1;
}

//for MG82FG5A64
void Timer0_ISR() interrupt 1		//0x000B
{
	TH0 = 100;	//default 為1/12 clock 計數一次，目前這個數值約1/40 sec 會產生一次中斷
	EA = 0;
		
	EA = 1;
}

void Timer1_ISR() interrupt 3		//0x001B
{
	EA = 0;
	
	EA = 1;
}

void Timer2_ISR() interrupt 5		//0x002B
{
	EA = 0;

	
	EA = 1;
}

void Timer3_ISR() interrupt 16	//0x0083
/*Timer3 每1 ms 中斷一次.
這個中斷並不會影響SFR_PAGE 的選擇. 
//改成僅保留兩組Firmware Timer*/
{
	Byte temp;
	EA = 0;
	TF3 = 0;	//TF3 must be cleared by software
/*	
	for(temp = 0; temp < 8; temp ++)
	{
		if(TimerRun[0] & (0x01 << temp))		//TimerRun = 1
		{
			if(TimerCurrentValue[temp] > 0)
			{
				TimerCurrentValue[temp] --;
			}
			else
			{
				if(TimerCurrentValue[temp] == 0)
				{
					TimeOut[0] |= (0x01 << temp);
				}
			}
		}
			
		if(TimerRun[1] & (0x01 << temp))		//TimerRun = 1
		{
			if(TimerCurrentValue[temp] > 0)
			{
				TimerCurrentValue[temp] --;
			}
			else
			{
				if(TimerCurrentValue[temp] == 0)
				{
					TimeOut[1] |= (0x01 << temp);
				}
			}
		}
	}	
*/
	if(CounterTime != 0)
	{		
		if((--CounterTime) == 0)
		{
			TimeFlag = 1;
		}
	}
	for(temp = 0; temp < 2; temp ++)
	{
		if(TimerRun[0] & (0x01 << temp))		//TimerRun = 1
		{
			if(TimerCurrentValue[temp] > 0)
			{
				TimerCurrentValue[temp]--;
			}
			else
			{
				if(TimerCurrentValue[temp] == 0)
				{
					TimeOut[0] |= (0x01 << temp);
				}
			}
		}
	}

	EA = 1;
}

Byte IsTimerAvailable(Byte TimerNo)
/*輸入TimerNo, 若該Timer 為Available (not run and Event == 0)
則會回應1. 若執行中則會回應 0*/
{
	if((TimerRun[0] & (0x01 << TimerNo)) || (TimeOut[0] & (0x01 << TimerNo)))
	{
		return 0;
	}
	else
	{
		return 1;
	}	
}

