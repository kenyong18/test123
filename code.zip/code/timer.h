//******************************************************************************//
//					Autolutiontech												//
//																				//
//			Timer.h																//
//																				//
//			Version 1.0															//
//																				//
//			Author: Frank Wang													//
//																				//
//			Date: 2014/11/09													//
//																				//
//******************************************************************************//

#ifndef	_TIMER_H_
#define _TIMER_H_

#include "main.h"

//#define TimerNumber		16
#define TimerNumber		2

//extern void MG82FG5A64_Timer0_Init();
//extern void MG82FG5A64_Timer1_Init();
//extern void MG82FG5A64_Timer2_Init();
extern void MG82FG5A64_Timer3_Init();

extern void SoftTimer_Init();
extern Byte IsTimerAvailable(Byte TimerNo);
extern Byte GetAvailableTimer();
extern void ReleaseTimer(Byte TimerNo);
extern void SetTimerTarget(Byte TimerNo, Word TimerValue);
extern void TimerStart(Byte TimerNo);
extern Byte CheckTimerEvent(Byte TimerNo);

extern Word idata TimerCurrentValue[TimerNumber];
//extern Byte bdata TimerRun[2];
//extern Byte bdata TimeOut[2];
extern Byte bdata TimerRun[1];
extern Byte bdata TimeOut[1];
extern Word idata CounterTime;
extern Byte bdata TimeFlag;

#endif

